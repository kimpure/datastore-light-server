return require(script.Parent._Index["dekkonot_base91@1.1.0"]["base91"])
