return require(script.Parent._Index["cipharius_msgpack-luau@0.3.0"]["msgpack-luau"])
