return require(script.Parent._Index["caveful-games_rbxzstd@0.1.0"]["rbxzstd"])
