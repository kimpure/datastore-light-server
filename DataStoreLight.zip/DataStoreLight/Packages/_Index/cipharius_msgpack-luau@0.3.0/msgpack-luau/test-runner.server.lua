local TestEZ = require(game.ReplicatedStorage.Packages.TestEZ)

TestEZ.TestBootstrap:run({game.ReplicatedStorage})
