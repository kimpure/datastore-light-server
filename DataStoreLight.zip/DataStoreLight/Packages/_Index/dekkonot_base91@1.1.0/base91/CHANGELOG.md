# Changelog

## Version 1.1.0

- Added support for `buffer` data type
- Marked module with `--!native` and `--!optimize 2`
- Redid documentation for module

## Version 1.0.0

- Initial release
